Sparse transfer face shape reconstruction tool v0.1
2015.3.6
------------------------------------------------------

The provided tool is a re-implementation of the paper:

[1] Jian-Fang Hu, Wei-Shi Zheng, Xiaohua Xie, and Jianhuang Lai.Sparse Transfer for Facial Shape-from-Shading

------------------------------------------------------

Prerequisites:
1. The provided tool is compiled for Windows 7, 64 bit. 

------------------------------------------------------

Example:

We have provided four reconstruction examples in this implementation. Please see the demoExample*.m for details. Specifically, demoExample1.m and demoExample4.m give the reconstruction examples of images downlaod from internet. demoExample2.m and demoExample3.m provide the reconstructions of images from Yale B and LFW, respectively.  

Note that all the images to be processed by our tool must be aligned with our reference models according to the locations of three face landmarks (centers of left eye, right eye and mouse). The detailed alignment algorithm will be released in future. Please refer to our paper for more details of our algorithm.


------------------------------------------------------

Should you have any questions, please feel free to drop me an email, hujianf@mail2.sysu.edu.cn.
