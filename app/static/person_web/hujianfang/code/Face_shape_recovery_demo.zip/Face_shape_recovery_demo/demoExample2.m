%% This code gives an example of our reconstruction of image from Yale B
%%
clear all; close all;
ImgPath='./Crop/';
%% Read image to be reconstructed
 personId=1;   imageId=3;
img=sprintf('%02i%02i',personId,imageId);
imDir=[ImgPath img];
targetImage=imread([imDir '.bmp']);
if size(targetImage,3)==1
   targetImage=repmat(targetImage,[1 1 3]);
end
maskFace=zeros(100);  maskFace(1:100,1:100)=1;        % Define the face region
inputIm=im2double(rgb2gray(targetImage));

%% Load reference info
poseId=0; [NormForTransfer, Rou]=readReferenceForWideImage(poseId);
Rou(personId)=[]; NormForTransfer(personId)=[];
figure,showing_imgset(Rou);   title('Albedo Learned From Yale B')
figure,showing_imgset(NormForTransfer,4,10); title('Normal Learned From Yale B')
pause(1/10);close all

%% Conduct reconstruction
lamda=20; beta=ones(length(NormForTransfer),1)/length(NormForTransfer); gamma=3000; deltaForRouRef=10;
tic; 
[NormalTr,Z,B,Beta,ErrorLearn,vecLighting,REF]=transferFaceSingleJF(NormForTransfer,inputIm,lamda,beta,gamma,deltaForRouRef,Rou,maskFace);
toc;   

figure,subplot(1,2,1);showing_faceMask(inputIm,maskFace); title('Input image: Gray')
subplot(1,2,2),showing_faceMask(double(targetImage)/255,maskFace); title('Input image: Color')

ratio=1.50;
figure,showing_face(-Z{end}(:,end:-1:1)/ratio,2);mouse3d;axis off
title('3D Shape')

[XX,YY]=meshgrid(1:100,1:100);
figure,warp(XX,YY,-Z{end}/ratio,double(targetImage)/255)
mouse3d
axis off
title('3D Shape with texture')