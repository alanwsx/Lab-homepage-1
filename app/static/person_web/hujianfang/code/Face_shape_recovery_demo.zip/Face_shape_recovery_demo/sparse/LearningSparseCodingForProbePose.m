function [CodingForEachProbePoseSetC] ...
               = LearningSparseCodingForProbePose(AtomicPoseSetC,ProbePoseSetC,gamma)

Sigma = eye(size(AtomicPoseSetC,2));
beta = 1e-5;                        % a small regularization for stablizing sparse coding
% gamma = 100;
CodingForEachProbePoseSetC ...
    = L1QP_FeatureSign_Set(ProbePoseSetC, AtomicPoseSetC, Sigma, beta, gamma);

